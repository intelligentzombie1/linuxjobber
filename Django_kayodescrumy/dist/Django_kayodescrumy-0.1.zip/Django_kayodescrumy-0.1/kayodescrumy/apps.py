from django.apps import AppConfig


class KayodescrumyConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'kayodescrumy'
